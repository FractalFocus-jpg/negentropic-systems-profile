#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

IN_SCOPE = [
    "byte_tamper", "manifest_tamper", "signature_tamper", "consistency_proof_tamper",
    "terminal_fork", "metrics_fork", "negative_cell_fork", "archive_fork", "claim_note_fork",
    "stale_head", "rollback", "duplicate_sequence", "receipt_replay", "predecessor_rewrite",
    "split_view", "cross_run_archive_splice", "cross_run_receipt_splice", "selective_disclosure", "key_substitution",
    "claim_ceiling_hash_splice", "custody_latest_pub_substitution", "protocol_hash_fork",
    "sequence_gap", "cross_root_gossip_splice",
]

def cjson(x):
    return (json.dumps(x, sort_keys=True, separators=(",", ":")) + "\n").encode()

def verify(pub_hex: str, obj, sig_hex: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex)).verify(bytes.fromhex(sig_hex), cjson(obj))
        return True
    except Exception:
        return False

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--result-dir", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    d = Path(a.result_dir)
    rows = [json.loads(x) for x in (d / "CASE_RESULTS.partial.jsonl").read_text().splitlines() if x.strip()]
    s = json.loads((d / "SUMMARY.json").read_text())
    receipt = json.loads((d / "RUN_RECEIPT.json").read_text())
    clean = int(s["clean_controls"])
    attacks = int(s["in_scope_attacks"])
    impossible = int(s["impossibility_controls"])
    checks = {}
    checks["row_count"] = len(rows) == clean + attacks + impossible
    checks["clean_count"] = sum(r["kind"] == "clean" for r in rows) == clean
    checks["attack_count"] = sum(r["kind"] == "attack" for r in rows) == attacks
    checks["impossibility_count"] = sum(r["kind"] == "impossibility" for r in rows) == impossible
    checks["qew_clean"] = sum(r["kind"] == "clean" and r["decisions"]["QEW1"] for r in rows) == clean
    checks["qew_attacks"] = sum(r["kind"] == "attack" and not r["decisions"]["QEW1"] for r in rows) == attacks
    checks["qew_collusion"] = sum(r["kind"] == "impossibility" and r["decisions"]["QEW1"] for r in rows) == impossible
    checks["family_coverage"] = set(r["family"] for r in rows if r["kind"] == "attack") == set(IN_SCOPE)
    normalized = [{"kind": r["kind"], "family": r["family"], "decisions": r["decisions"]} for r in rows]
    h = hashlib.sha256(cjson(normalized)).hexdigest()
    checks["scientific_hash"] = h == s["scientific_sha256"] == receipt["body"]["scientific_sha256"]
    checks["summary_pass"] = bool(s["overall_pass"])
    checks["private_keys_deleted"] = bool(s.get("private_keys_deleted")) and not (d / ".evaluator_key.raw").exists() and not (d / ".custody_key.raw").exists()
    pubs = receipt["body"]["public_keys"]
    checks["evaluator_receipt_signature"] = verify(pubs["evaluator"], receipt["body"], receipt["evaluator_signature"])
    checks["custody_receipt_signature"] = verify(pubs["custody"], receipt["body"], receipt["custody_signature"])
    out = {
        "checks": checks,
        "pass": all(checks.values()),
        "scientific_sha256": h,
        "rows": len(rows),
        "environment": s.get("environment"),
    }
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n")
    print(json.dumps(out, indent=2, sort_keys=True))
    raise SystemExit(0 if out["pass"] else 2)

if __name__ == "__main__":
    main()
