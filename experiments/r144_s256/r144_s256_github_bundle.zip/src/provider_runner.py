#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, platform, secrets, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPERIMENT = ROOT / 'qew2_experiment.py'
VERIFIER = ROOT / 'independent_verifier.py'

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def line_count(path: Path) -> int:
    if not path.exists():
        return 0
    with path.open('rb') as f:
        return sum(1 for _ in f)

def run(cmd, *, cwd=None, check=True):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if check and p.returncode != 0:
        raise RuntimeError(f'command failed {p.returncode}: {cmd}\n{p.stdout}')
    return p

def main() -> int:
    out_root = Path(os.environ.get('QEW_OUTDIR', 'provider_output')).resolve()
    if out_root.exists():
        shutil.rmtree(out_root)
    out_root.mkdir(parents=True)
    seed = int(os.environ.get('QEW_SEED', str(secrets.randbits(63))))
    run_dir = out_root / 'run'
    replay_dir = out_root / 'replay'
    run_dir.mkdir(); replay_dir.mkdir()

    # Actual process interruption after a frozen persisted-case threshold.
    cmd = [sys.executable, str(EXPERIMENT), '--outdir', str(run_dir), '--seed', str(seed), '--clean', '100', '--per-attack', '100']
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    partial = run_dir / 'CASE_RESULTS.partial.jsonl'
    deadline = time.time() + 180
    while time.time() < deadline and proc.poll() is None:
        if line_count(partial) >= 733:
            proc.kill()
            break
        time.sleep(0.05)
    interrupted_rc = proc.wait(timeout=15)
    interrupted_lines = line_count(partial)
    if interrupted_lines < 733:
        tail = ''
        if proc.stdout:
            tail = proc.stdout.read()[-4000:]
        raise RuntimeError(f'interruption threshold not reached: lines={interrupted_lines}, rc={interrupted_rc}\n{tail}')

    resume = run(cmd + ['--resume'], check=True)
    (out_root / 'RESUME_STDOUT.txt').write_text(resume.stdout, encoding='utf-8')
    verify_path = out_root / 'INDEPENDENT_VERIFIER.json'
    verifier = run([sys.executable, str(VERIFIER), '--result-dir', str(run_dir), '--out', str(verify_path)], check=True)
    (out_root / 'VERIFIER_STDOUT.txt').write_text(verifier.stdout, encoding='utf-8')

    replay = run([sys.executable, str(EXPERIMENT), '--outdir', str(replay_dir), '--seed', str(seed), '--clean', '100', '--per-attack', '100'], check=True)
    (out_root / 'REPLAY_STDOUT.txt').write_text(replay.stdout, encoding='utf-8')
    replay_verify_path = out_root / 'REPLAY_INDEPENDENT_VERIFIER.json'
    replay_verifier = run([sys.executable, str(VERIFIER), '--result-dir', str(replay_dir), '--out', str(replay_verify_path)], check=True)
    (out_root / 'REPLAY_VERIFIER_STDOUT.txt').write_text(replay_verifier.stdout, encoding='utf-8')

    summary = json.loads((run_dir / 'SUMMARY.json').read_text())
    replay_summary = json.loads((replay_dir / 'SUMMARY.json').read_text())
    verifier_obj = json.loads(verify_path.read_text())
    replay_verifier_obj = json.loads(replay_verify_path.read_text())
    replay_match = summary['scientific_sha256'] == replay_summary['scientific_sha256']
    result = {
        'program': 'R144-S256',
        'study': 'QEW-2 Cross-Provider Quorum Evaluation Rehearsal',
        'provider': {
            'platform': platform.platform(),
            'python': sys.version,
            'runner_os': os.environ.get('RUNNER_OS', platform.system()),
            'runner_arch': os.environ.get('RUNNER_ARCH', platform.machine()),
            'github_run_id': os.environ.get('GITHUB_RUN_ID'),
            'github_run_attempt': os.environ.get('GITHUB_RUN_ATTEMPT'),
        },
        'seed': seed,
        'interruption': {
            'actual_process_kill': True,
            'return_code': interrupted_rc,
            'persisted_cases': interrupted_lines,
            'threshold': 733,
        },
        'summary': summary,
        'fresh_replay_scientific_sha256': replay_summary['scientific_sha256'],
        'fresh_replay_exact': replay_match,
        'independent_verifier_pass': verifier_obj['pass'],
        'replay_independent_verifier_pass': replay_verifier_obj['pass'],
        'artifact_hashes': {
            'run_summary': sha(run_dir / 'SUMMARY.json'),
            'run_receipt': sha(run_dir / 'RUN_RECEIPT.json'),
            'run_cases': sha(run_dir / 'CASE_RESULTS.partial.jsonl'),
            'verifier': sha(verify_path),
            'replay_summary': sha(replay_dir / 'SUMMARY.json'),
        },
    }
    result['overall_pass'] = bool(
        summary['overall_pass']
        and summary.get('private_keys_deleted')
        and replay_match
        and verifier_obj['pass']
        and replay_verifier_obj['pass']
    )
    (out_root / 'PROVIDER_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({
        'overall_pass': result['overall_pass'],
        'runner_os': result['provider']['runner_os'],
        'seed': seed,
        'scientific_sha256': summary['scientific_sha256'],
        'advantage_pp': summary['qew_advantage_percentage_points'],
        'persisted_before_kill': interrupted_lines,
    }, indent=2, sort_keys=True))
    return 0 if result['overall_pass'] else 2

if __name__ == '__main__':
    raise SystemExit(main())
