#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, hashlib, json, os, platform, random, signal, sys, time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

METHODS = ["SIGNED_BLOB", "SINGLE_WITNESS", "DETACHED_DUAL", "SINGLE_MERKLE", "QEW1"]
IN_SCOPE_ATTACKS = [
    "byte_tamper", "manifest_tamper", "signature_tamper", "consistency_proof_tamper",
    "terminal_fork", "metrics_fork", "negative_cell_fork", "archive_fork", "claim_note_fork",
    "stale_head", "rollback", "duplicate_sequence", "receipt_replay", "predecessor_rewrite",
    "split_view", "cross_run_archive_splice", "cross_run_receipt_splice", "selective_disclosure", "key_substitution",
    "claim_ceiling_hash_splice", "custody_latest_pub_substitution", "protocol_hash_fork",
    "sequence_gap", "cross_root_gossip_splice"
]
IMPOSSIBILITY_ATTACK = "full_collusion_consistent_fork"
CLAIM_CEILING = [
    "cross-provider split-view integrity advantage within frozen contract",
    "underlying scientific truth not established by witness",
    "unaffiliated evaluator validation remains open",
    "production superiority remains open",
    "unrestricted universal implementation superiority is not a coherent claim under comparator closure"
]

def cjson(x) -> bytes:
    return (json.dumps(x, sort_keys=True, separators=(",", ":")) + "\n").encode()

def sha(x: bytes) -> str:
    return hashlib.sha256(x).hexdigest()

def pubhex(priv: Ed25519PrivateKey) -> str:
    return priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()

def sign(priv: Ed25519PrivateKey, obj) -> str:
    return priv.sign(cjson(obj)).hex()

def verify(pub_hex: str, obj, sig_hex: str) -> bool:
    try:
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub_hex)).verify(bytes.fromhex(sig_hex), cjson(obj))
        return True
    except Exception:
        return False

def merkle_root(leaves: List[dict]) -> str:
    nodes = [bytes.fromhex(sha(cjson(x))) for x in leaves]
    if not nodes:
        return sha(b"")
    while len(nodes) > 1:
        if len(nodes) % 2:
            nodes.append(nodes[-1])
        nodes = [hashlib.sha256(nodes[i] + nodes[i+1]).digest() for i in range(0, len(nodes), 2)]
    return nodes[0].hex()

def base_record(seed: int, idx: int) -> dict:
    rng = random.Random((seed << 16) ^ idx)
    outcomes = [rng.randint(0, 1) for _ in range(32)]
    negatives = [i for i, v in enumerate(outcomes) if v == 0][:4]
    terminal = "PASS" if sum(outcomes) >= 16 else "FAIL"
    metrics = {
        "score": round(sum(outcomes)/32, 6),
        "positive_cells": int(sum(outcomes)),
        "total_cells": 32,
    }
    evidence = [{"case": i, "result": v, "digest": sha(f"{seed}:{idx}:{i}:{v}".encode())} for i, v in enumerate(outcomes)]
    rec = {
        "protocol_sha256": sha(b"R144-S256-QEW2-PROTOCOL-v1"),
        "run_id": f"run-{seed}-{idx}",
        "sequence": 100,
        "expected_denominator": 32,
        "observed_denominator": 32,
        "first_terminal": terminal,
        "negative_cells": negatives,
        "metrics": metrics,
        "claim_ceiling": CLAIM_CEILING,
        "evidence": evidence,
        "archive_sha256": sha(cjson(evidence)),
        "predecessor_receipt_sha256": sha(f"pred:{seed}:{idx}".encode()),
    }
    return rec

def leaves_for(rec: dict) -> List[dict]:
    meta = {k: rec[k] for k in rec if k != "evidence"}
    return [{"type": "meta", "value": meta}] + [{"type": "case", "value": x} for x in rec["evidence"]]

def build_package(rec: dict, eval_priv, custody_priv, previous_root: str, custody_latest: dict) -> dict:
    leaves = leaves_for(rec)
    root = merkle_root(leaves)
    semantic = {k: rec[k] for k in rec if k != "evidence"}
    eval_blob = {"semantic": semantic, "manifest_root": root}
    single_sig = sign(eval_priv, eval_blob)
    detached_custody_obj = {"archive_sha256": rec["archive_sha256"]}
    detached_custody_sig = sign(custody_priv, detached_custody_obj)
    merkle_head = {"run_id": rec["run_id"], "sequence": rec["sequence"], "root": root}
    merkle_eval_sig = sign(eval_priv, merkle_head)
    quorum_head = {
        "run_id": rec["run_id"],
        "sequence": rec["sequence"],
        "root": root,
        "previous_root": previous_root,
        "protocol_sha256": rec["protocol_sha256"],
        "claim_ceiling_sha256": sha(cjson(rec["claim_ceiling"])),
    }
    pkg = {
        "record": rec,
        "leaves": leaves,
        "root": root,
        "eval_pub": pubhex(eval_priv),
        "custody_pub": pubhex(custody_priv),
        "signed_blob_sig": sign(eval_priv, rec),
        "single_witness_obj": eval_blob,
        "single_witness_sig": single_sig,
        "detached_custody_obj": detached_custody_obj,
        "detached_custody_sig": detached_custody_sig,
        "single_merkle_head": merkle_head,
        "single_merkle_sig": merkle_eval_sig,
        "quorum_head": quorum_head,
        "quorum_eval_sig": sign(eval_priv, quorum_head),
        "quorum_custody_sig": sign(custody_priv, quorum_head),
        "custody_latest": custody_latest,
    }
    return pkg

def internally_consistent(rec: dict) -> bool:
    try:
        if rec["observed_denominator"] != len(rec["evidence"]):
            return False
        if rec["expected_denominator"] != 32:
            return False
        if rec["archive_sha256"] != sha(cjson(rec["evidence"])):
            return False
        if rec["metrics"]["total_cells"] != 32:
            return False
        if rec["metrics"]["positive_cells"] != sum(int(x["result"]) for x in rec["evidence"]):
            return False
        if rec["metrics"]["score"] != round(rec["metrics"]["positive_cells"]/32, 6):
            return False
        negatives = [x["case"] for x in rec["evidence"] if x["result"] == 0][:4]
        if rec["negative_cells"] != negatives:
            return False
        terminal = "PASS" if rec["metrics"]["positive_cells"] >= 16 else "FAIL"
        if rec["first_terminal"] != terminal:
            return False
        if rec["claim_ceiling"] != CLAIM_CEILING:
            return False
        return True
    except Exception:
        return False

def v_signed_blob(pkg: dict) -> bool:
    return verify(pkg["eval_pub"], pkg["record"], pkg["signed_blob_sig"])

def v_single_witness(pkg: dict) -> bool:
    return internally_consistent(pkg["record"]) and verify(pkg["eval_pub"], pkg["single_witness_obj"], pkg["single_witness_sig"])

def v_detached_dual(pkg: dict) -> bool:
    return (internally_consistent(pkg["record"]) and
            verify(pkg["eval_pub"], pkg["single_witness_obj"], pkg["single_witness_sig"]) and
            verify(pkg["custody_pub"], pkg["detached_custody_obj"], pkg["detached_custody_sig"]))

def v_single_merkle(pkg: dict) -> bool:
    return (merkle_root(pkg["leaves"]) == pkg["root"] and
            verify(pkg["eval_pub"], pkg["single_merkle_head"], pkg["single_merkle_sig"]))

def v_qew(pkg: dict) -> bool:
    rec = pkg["record"]
    if not internally_consistent(rec):
        return False
    if pkg["leaves"] != leaves_for(rec):
        return False
    if merkle_root(pkg["leaves"]) != pkg["root"]:
        return False
    h = pkg["quorum_head"]
    if h["root"] != pkg["root"] or h["run_id"] != rec["run_id"] or h["sequence"] != rec["sequence"]:
        return False
    if h["protocol_sha256"] != rec["protocol_sha256"]:
        return False
    if h["claim_ceiling_sha256"] != sha(cjson(rec["claim_ceiling"])):
        return False
    if not verify(pkg["eval_pub"], h, pkg["quorum_eval_sig"]):
        return False
    if not verify(pkg["custody_pub"], h, pkg["quorum_custody_sig"]):
        return False
    latest = pkg["custody_latest"]
    if latest.get("eval_pub") != pkg["eval_pub"] or latest.get("custody_pub") != pkg["custody_pub"]:
        return False
    if latest["run_id"] != h["run_id"] or latest["sequence"] != h["sequence"] or latest["root"] != h["root"]:
        return False
    return True

VERIFIERS = {
    "SIGNED_BLOB": v_signed_blob,
    "SINGLE_WITNESS": v_single_witness,
    "DETACHED_DUAL": v_detached_dual,
    "SINGLE_MERKLE": v_single_merkle,
    "QEW1": v_qew,
}

def resign_evaluator(pkg, eval_priv):
    pkg["eval_pub"] = pubhex(eval_priv)
    pkg["signed_blob_sig"] = sign(eval_priv, pkg["record"])
    pkg["single_witness_obj"] = {"semantic": {k: pkg["record"][k] for k in pkg["record"] if k != "evidence"}, "manifest_root": pkg["root"]}
    pkg["single_witness_sig"] = sign(eval_priv, pkg["single_witness_obj"])
    pkg["single_merkle_head"] = {"run_id": pkg["record"]["run_id"], "sequence": pkg["record"]["sequence"], "root": pkg["root"]}
    pkg["single_merkle_sig"] = sign(eval_priv, pkg["single_merkle_head"])
    pkg["quorum_head"] = {
        "run_id": pkg["record"]["run_id"], "sequence": pkg["record"]["sequence"], "root": pkg["root"],
        "previous_root": pkg["quorum_head"]["previous_root"], "protocol_sha256": pkg["record"]["protocol_sha256"],
        "claim_ceiling_sha256": sha(cjson(pkg["record"]["claim_ceiling"]))
    }
    pkg["quorum_eval_sig"] = sign(eval_priv, pkg["quorum_head"])

def refresh_record(pkg):
    pkg["record"]["archive_sha256"] = sha(cjson(pkg["record"]["evidence"]))
    pos = sum(int(x["result"]) for x in pkg["record"]["evidence"])
    pkg["record"]["observed_denominator"] = len(pkg["record"]["evidence"])
    pkg["record"]["metrics"] = {"score": round(pos/32, 6), "positive_cells": pos, "total_cells": 32}
    pkg["record"]["negative_cells"] = [x["case"] for x in pkg["record"]["evidence"] if x["result"] == 0][:4]
    pkg["record"]["first_terminal"] = "PASS" if pos >= 16 else "FAIL"
    pkg["leaves"] = leaves_for(pkg["record"])
    pkg["root"] = merkle_root(pkg["leaves"])

def attack_package(canon: dict, family: str, rng: random.Random, eval_priv, custody_priv, alternate: dict) -> dict:
    # deep copy by canonical JSON
    pkg = json.loads(json.dumps(canon))
    if family == "byte_tamper":
        pkg["record"]["metrics"]["score"] = round(pkg["record"]["metrics"]["score"] + 0.01, 6)
    elif family == "manifest_tamper":
        pkg["leaves"][1]["value"]["digest"] = "00" * 32
    elif family == "signature_tamper":
        pkg["signed_blob_sig"] = ("00" * 64)
        pkg["single_witness_sig"] = ("00" * 64)
        pkg["single_merkle_sig"] = ("00" * 64)
        pkg["quorum_eval_sig"] = ("00" * 64)
    elif family == "consistency_proof_tamper":
        pkg["quorum_head"]["previous_root"] = "11" * 32
        pkg["quorum_eval_sig"] = sign(eval_priv, pkg["quorum_head"])
    elif family in {"terminal_fork", "metrics_fork", "negative_cell_fork", "archive_fork", "claim_note_fork", "split_view"}:
        # evaluator-signed alternate, internally self-consistent view; custody remains canonical
        pkg["record"] = json.loads(json.dumps(alternate["record"]))
        pkg["record"]["run_id"] = canon["record"]["run_id"]
        pkg["record"]["sequence"] = canon["record"]["sequence"]
        if family == "claim_note_fork":
            # remain schema-valid for single-view methods by changing a non-ceiling annotation
            pkg["record"]["review_note"] = "alternate-authorized-narrative"
        refresh_record(pkg)
        resign_evaluator(pkg, eval_priv)
        # detached custody signature stays valid if archive matches canonical only; for archive forks splice alternate valid signature
        if family in {"archive_fork", "split_view"}:
            pkg["detached_custody_obj"] = alternate["detached_custody_obj"]
            pkg["detached_custody_sig"] = alternate["detached_custody_sig"]
        pkg["custody_latest"] = canon["custody_latest"]
    elif family == "stale_head":
        pkg["record"]["sequence"] = 99
        refresh_record(pkg); resign_evaluator(pkg, eval_priv)
        pkg["quorum_head"]["sequence"] = 99
        pkg["quorum_eval_sig"] = sign(eval_priv, pkg["quorum_head"])
    elif family == "rollback":
        pkg["record"]["sequence"] = 90
        refresh_record(pkg); resign_evaluator(pkg, eval_priv)
        # keep old valid custody signature from a separately signed historical head
        old = dict(pkg["quorum_head"]); old["sequence"] = 90; old["root"] = pkg["root"]
        pkg["quorum_head"] = old
        pkg["quorum_eval_sig"] = sign(eval_priv, old)
        pkg["quorum_custody_sig"] = sign(custody_priv, old)
    elif family == "duplicate_sequence":
        pkg["record"] = json.loads(json.dumps(alternate["record"]))
        pkg["record"]["run_id"] = canon["record"]["run_id"]
        pkg["record"]["sequence"] = canon["record"]["sequence"]
        refresh_record(pkg); resign_evaluator(pkg, eval_priv)
        pkg["custody_latest"] = canon["custody_latest"]
    elif family == "receipt_replay":
        pkg["record"]["run_id"] = alternate["record"]["run_id"]
        refresh_record(pkg); resign_evaluator(pkg, eval_priv)
        pkg["quorum_head"] = canon["quorum_head"]
        pkg["quorum_eval_sig"] = canon["quorum_eval_sig"]
        pkg["quorum_custody_sig"] = canon["quorum_custody_sig"]
    elif family == "predecessor_rewrite":
        pkg["record"]["predecessor_receipt_sha256"] = "22" * 32
        refresh_record(pkg); resign_evaluator(pkg, eval_priv)
    elif family == "cross_run_archive_splice":
        pkg["record"]["archive_sha256"] = alternate["record"]["archive_sha256"]
        pkg["detached_custody_obj"] = alternate["detached_custody_obj"]
        pkg["detached_custody_sig"] = alternate["detached_custody_sig"]
        resign_evaluator(pkg, eval_priv)
    elif family == "cross_run_receipt_splice":
        pkg["quorum_head"] = alternate["quorum_head"]
        pkg["quorum_eval_sig"] = alternate["quorum_eval_sig"]
        pkg["quorum_custody_sig"] = alternate["quorum_custody_sig"]
    elif family == "selective_disclosure":
        pkg["leaves"] = pkg["leaves"][:-1]
        pkg["root"] = merkle_root(pkg["leaves"])
        resign_evaluator(pkg, eval_priv)
    elif family == "key_substitution":
        evil = Ed25519PrivateKey.generate()
        resign_evaluator(pkg, evil)
        pkg["eval_pub"] = pubhex(evil)
    elif family == "claim_ceiling_hash_splice":
        pkg["record"]["claim_ceiling"] = list(pkg["record"]["claim_ceiling"]) + ["unauthorized promotion"]
        pkg["leaves"] = leaves_for(pkg["record"])
        pkg["root"] = merkle_root(pkg["leaves"])
        resign_evaluator(pkg, eval_priv)
        # custody quorum head intentionally remains bound to the frozen ceiling hash
        pkg["custody_latest"] = canon["custody_latest"]
    elif family == "custody_latest_pub_substitution":
        pkg["custody_latest"] = dict(pkg["custody_latest"])
        pkg["custody_latest"]["custody_pub"] = ("ab" * 32)
    elif family == "protocol_hash_fork":
        pkg["record"]["protocol_sha256"] = ("cd" * 32)
        refresh_record(pkg)
        resign_evaluator(pkg, eval_priv)
        pkg["custody_latest"] = canon["custody_latest"]
    elif family == "sequence_gap":
        pkg["record"]["sequence"] = canon["record"]["sequence"] + 2
        refresh_record(pkg)
        resign_evaluator(pkg, eval_priv)
        pkg["custody_latest"] = canon["custody_latest"]
    elif family == "cross_root_gossip_splice":
        pkg["custody_latest"] = dict(pkg["custody_latest"])
        pkg["custody_latest"]["root"] = alternate["root"]
    else:
        raise ValueError(family)
    return pkg

def collusion_package(canon, eval_priv, custody_priv, alternate):
    pkg = json.loads(json.dumps(alternate))
    pkg["record"]["run_id"] = canon["record"]["run_id"]
    pkg["record"]["sequence"] = canon["record"]["sequence"]
    refresh_record(pkg)
    resign_evaluator(pkg, eval_priv)
    pkg["detached_custody_obj"] = {"archive_sha256": pkg["record"]["archive_sha256"]}
    pkg["detached_custody_sig"] = sign(custody_priv, pkg["detached_custody_obj"])
    pkg["quorum_custody_sig"] = sign(custody_priv, pkg["quorum_head"])
    pkg["custody_latest"] = {"run_id": pkg["record"]["run_id"], "sequence": pkg["record"]["sequence"], "root": pkg["root"], "eval_pub": pubhex(eval_priv), "custody_pub": pubhex(custody_priv)}
    return pkg

def case_sequence(seed: int, clean: int, per_attack: int):
    for i in range(clean):
        yield {"kind": "clean", "family": "clean", "index": i}
    for fam in IN_SCOPE_ATTACKS:
        for i in range(per_attack):
            yield {"kind": "attack", "family": fam, "index": i}
    for i in range(per_attack):
        yield {"kind": "impossibility", "family": IMPOSSIBILITY_ATTACK, "index": i}

def _load_or_create_key(path: Path):
    if path.exists():
        return Ed25519PrivateKey.from_private_bytes(path.read_bytes())
    key = Ed25519PrivateKey.generate()
    path.write_bytes(key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()))
    return key

def run_bank(outdir: Path, seed: int, clean: int, per_attack: int, resume: bool, stop_after: int|None):
    outdir.mkdir(parents=True, exist_ok=True)
    partial = outdir / "CASE_RESULTS.partial.jsonl"
    eval_key_path = outdir / ".evaluator_key.raw"
    custody_key_path = outdir / ".custody_key.raw"
    done = 0
    if resume and partial.exists():
        done = sum(1 for _ in partial.open("r", encoding="utf-8"))
    eval_priv = _load_or_create_key(eval_key_path)
    custody_priv = _load_or_create_key(custody_key_path)
    rng = random.Random(seed)
    cases = list(case_sequence(seed, clean, per_attack))
    with partial.open("a", encoding="utf-8") as f:
        for pos, spec in enumerate(cases):
            if pos < done:
                continue
            idx = spec["index"]
            rec = base_record(seed, pos)
            previous_root = sha(f"prev:{seed}:{pos}".encode())
            latest = {"run_id": rec["run_id"], "sequence": rec["sequence"], "root": merkle_root(leaves_for(rec)), "eval_pub": pubhex(eval_priv), "custody_pub": pubhex(custody_priv)}
            canon = build_package(rec, eval_priv, custody_priv, previous_root, latest)
            alt_rec = base_record(seed ^ 0x5A5A5A, pos + 100000)
            alt_latest = {"run_id": alt_rec["run_id"], "sequence": alt_rec["sequence"], "root": merkle_root(leaves_for(alt_rec)), "eval_pub": pubhex(eval_priv), "custody_pub": pubhex(custody_priv)}
            alternate = build_package(alt_rec, eval_priv, custody_priv, sha(f"altprev:{seed}:{pos}".encode()), alt_latest)
            if spec["kind"] == "clean":
                pkg = canon; expected = True
            elif spec["kind"] == "attack":
                pkg = attack_package(canon, spec["family"], rng, eval_priv, custody_priv, alternate); expected = False
            else:
                pkg = collusion_package(canon, eval_priv, custody_priv, alternate); expected = True
            decisions = {m: bool(VERIFIERS[m](pkg)) for m in METHODS}
            row = {"position": pos, "kind": spec["kind"], "family": spec["family"], "expected_qew_accept": expected, "decisions": decisions}
            f.write(json.dumps(row, sort_keys=True) + "\n"); f.flush(); os.fsync(f.fileno())
            if stop_after is not None and pos + 1 >= stop_after:
                return 75
    rows = [json.loads(x) for x in partial.read_text(encoding="utf-8").splitlines() if x.strip()]
    summary = summarize(rows, clean, per_attack)
    summary["environment"] = {
        "platform": platform.platform(),
        "python": sys.version,
        "runner_os": os.environ.get("RUNNER_OS", "local"),
        "runner_arch": os.environ.get("RUNNER_ARCH", platform.machine()),
        "github_run_id": os.environ.get("GITHUB_RUN_ID"),
        "github_run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),
    }
    summary["seed"] = seed
    (outdir/"SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    public_keys = {"evaluator": pubhex(eval_priv), "custody": pubhex(custody_priv)}
    (outdir/"PUBLIC_KEYS.json").write_text(json.dumps(public_keys, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    receipt_body = {
        "program": summary["program"], "study": summary["study"],
        "scientific_sha256": summary["scientific_sha256"],
        "overall_pass": summary["overall_pass"],
        "environment": summary["environment"],
        "seed": seed, "public_keys": public_keys,
    }
    receipt = {
        "body": receipt_body,
        "evaluator_signature": sign(eval_priv, receipt_body),
        "custody_signature": sign(custody_priv, receipt_body),
    }
    (outdir/"RUN_RECEIPT.json").write_text(json.dumps(receipt, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    # Fail closed on private-key persistence after receipt issuance.
    eval_key_path.unlink(missing_ok=True); custody_key_path.unlink(missing_ok=True)
    summary["private_keys_deleted"] = not eval_key_path.exists() and not custody_key_path.exists()
    (outdir/"SUMMARY.json").write_text(json.dumps(summary, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    return 0 if summary["overall_pass"] and summary["private_keys_deleted"] else 2

def summarize(rows, clean, per_attack):
    counts = {m: {"clean_accept":0,"in_scope_reject":0,"in_scope_accept":0,"collusion_accept":0} for m in METHODS}
    by_family = {fam:{m:{"accept":0,"reject":0} for m in METHODS} for fam in ["clean"]+IN_SCOPE_ATTACKS+[IMPOSSIBILITY_ATTACK]}
    for r in rows:
        for m,d in r["decisions"].items():
            by_family[r["family"]][m]["accept" if d else "reject"] += 1
            if r["kind"]=="clean" and d: counts[m]["clean_accept"] += 1
            elif r["kind"]=="attack": counts[m]["in_scope_accept" if d else "in_scope_reject"] += 1
            elif r["kind"]=="impossibility" and d: counts[m]["collusion_accept"] += 1
    total_att = len(IN_SCOPE_ATTACKS)*per_attack
    rates = {m: counts[m]["in_scope_reject"]/total_att for m in METHODS}
    strongest = max(rates[m] for m in METHODS if m!="QEW1")
    advantage_pp = (rates["QEW1"]-strongest)*100
    normalized = [{"kind":r["kind"],"family":r["family"],"decisions":r["decisions"]} for r in rows]
    sci_hash = sha(cjson(normalized))
    criteria = {
        "all_clean_controls_accepted": counts["QEW1"]["clean_accept"] == clean,
        "all_in_scope_attacks_rejected": counts["QEW1"]["in_scope_reject"] == total_att,
        "false_accept_zero": counts["QEW1"]["in_scope_accept"] == 0,
        "false_reject_zero": counts["QEW1"]["clean_accept"] == clean,
        "advantage_at_least_20pp": advantage_pp >= 20.0,
        "collusion_boundary_preserved": counts["QEW1"]["collusion_accept"] == per_attack,
    }
    return {
        "program":"R144-S256","study":"QEW-2 Cross-Provider Quorum Evaluation Rehearsal",
        "rows":len(rows),"clean_controls":clean,"in_scope_attacks":total_att,"impossibility_controls":per_attack,
        "methods":counts,"detection_rates":rates,"strongest_baseline_detection":strongest,
        "qew_advantage_percentage_points":advantage_pp,"by_family":by_family,
        "scientific_sha256":sci_hash,"criteria":criteria,"overall_pass":all(criteria.values()),
        "claim_ceiling":CLAIM_CEILING,
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--outdir",required=True); ap.add_argument("--seed",type=int,default=25620261020)
    ap.add_argument("--clean",type=int,default=100); ap.add_argument("--per-attack",type=int,default=100)
    ap.add_argument("--resume",action="store_true"); ap.add_argument("--stop-after",type=int)
    args=ap.parse_args(); raise SystemExit(run_bank(Path(args.outdir),args.seed,args.clean,args.per_attack,args.resume,args.stop_after))
if __name__=="__main__": main()
