# R144-S257A - Public-Beacon Blind Quorum Rehearsal - Frozen Preregistration

**Frozen date:** 2026-10-20  
**Parent:** R144-S256 Cross-Provider Quorum Frontier  
**External gate preserved:** R144-S257B Unaffiliated Blind Quorum Challenge

## Objective

Test whether the QEW evidence-integrity advantage survives when the attack-bank seed is derived only after candidate and protocol freeze from a cryptographically verified future public randomness beacon. Measure the selection inflation produced by post-result seed discretion, and verify the quorum safety/liveness threshold boundary by exhaustive finite enumeration.

## Public randomness contract

- Source: League of Entropy drand default chain.
- Client: `drand-client` version 1.4.2 with beacon verification enabled.
- Chain hash: `8990e7a9aaed2ffed73dbd7092123d6f289930540d7651336225dc172e51b2ce`.
- The GitHub commit containing the candidate, workflow, and protocol must exist before beacon acquisition.
- The beacon job waits at least 35 seconds after job start, then fetches and verifies the latest beacon.
- The derived seed is SHA-256 over program ID, frozen protocol label, chain hash, beacon round, beacon randomness, and frozen GitHub commit SHA.
- All provider jobs must consume the same beacon record and derive the same seed.

## Provider bank

Three GitHub-hosted environments:

1. Ubuntu 22.04
2. Ubuntu 24.04
3. Windows Server 2022

Each environment executes:

- 100 clean controls;
- 24 in-scope attack families x 100 trials = 2,400 attacks;
- 100 full-collusion consistent-fork controls;
- one actual process interruption after at least 911 persisted cases;
- exact resume;
- complete fresh replay;
- separately written verifier.

## Seed-discretion study

For true mean advantages -5, 0, and +5 percentage points, simulate 100,000 studies with sigma 10 percentage points. Compare one-shot public-beacon and precommitted seeds against best-of-4/8/16/32, first-nonnegative, and publish-only-if-nonnegative strategies.

Frozen success checks under the null:

1. public-beacon absolute bias <= 0.1 percentage points;
2. precommitted one-shot absolute bias <= 0.1 percentage points;
3. best-of-16 bias >= 10 percentage points;
4. best-of-32 bias >= 15 percentage points;
5. best-of-16 false promotion at 20 percentage points is at least 10x the one-shot rate.

## Quorum threshold model

Exhaustively enumerate all `(n,f,q)` with `1 <= n <= 12`, `0 <= f < n`, and `1 <= q <= n`.

Frozen formulas:

- safety iff `2q > n + f`;
- liveness iff `q <= n - f`;
- joint feasibility iff `n > 3f`;
- canonical threshold at `n = 3f + 1` is `q = 2f + 1`.

## Promotion criteria

All must pass:

1. one verified beacon round and randomness shared by all providers;
2. one derived seed shared by all providers;
3. one scientific hash shared by all providers;
4. 100/100 clean controls accepted per provider;
5. 2,400/2,400 in-scope attacks rejected per provider;
6. 100/100 full-collusion controls accepted per provider;
7. at least 20 percentage-point advantage over the strongest frozen baseline per provider;
8. exact interruption resume, fresh replay, and independent verifier per provider;
9. all selection-bias checks pass;
10. all quorum-threshold checks pass;
11. no post-result bank, threshold, comparator, or claim-ceiling changes.

## Claim ceiling

A pass supports:

- measurable suppression of seed-selection bias by one-shot future public randomness;
- same-party beacon-seeded cross-provider split-view integrity replication;
- contract-relative quorum threshold necessity under the frozen model.

A pass does **not** establish:

- unaffiliated evaluator-owned authority;
- certification of the underlying scientific subject;
- natural-workload or production superiority;
- full-collusion detection without independent information;
- unrestricted universal implementation superiority.
