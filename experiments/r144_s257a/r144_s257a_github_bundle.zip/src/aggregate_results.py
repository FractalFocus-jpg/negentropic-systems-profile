#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path


def cjson(x): return (json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n').encode()


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--root', required=True); ap.add_argument('--out', required=True); a = ap.parse_args()
    files = sorted(Path(a.root).rglob('PROVIDER_RESULT.json'))
    results = [json.loads(p.read_text()) for p in files]
    rounds = {x['beacon']['round'] for x in results}; randomness = {x['beacon']['randomness'] for x in results}; seeds = {x['derived_seed'] for x in results}; scientific = {x['summary']['scientific_sha256'] for x in results}
    checks = {
        'at_least_three_providers': len(results) >= 3,
        'single_verified_beacon_round': len(rounds) == 1 and all(x['beacon']['cryptographically_verified_by_client'] for x in results),
        'single_beacon_randomness': len(randomness) == 1,
        'single_derived_seed': len(seeds) == 1,
        'single_scientific_hash': len(scientific) == 1,
        'all_provider_pass': all(x.get('overall_pass') for x in results),
        'all_clean_accepted': all(x['summary']['methods']['QEW1']['clean_accept'] == 100 for x in results),
        'all_attacks_rejected': all(x['summary']['methods']['QEW1']['in_scope_reject'] == 2400 for x in results),
        'all_collusion_boundaries_preserved': all(x['summary']['methods']['QEW1']['collusion_accept'] == 100 for x in results),
        'all_advantage_at_least_20pp': all(x['summary']['qew_advantage_percentage_points'] >= 20 for x in results),
        'all_fresh_replay_exact': all(x['fresh_replay_exact'] for x in results),
        'all_actual_interruptions': all(x['interruption']['actual_process_kill'] and x['interruption']['persisted_cases'] >= 911 for x in results),
        'all_verifiers_pass': all(x['independent_verifier_pass'] and x['replay_independent_verifier_pass'] for x in results),
    }
    normalized = [{'runner_os': x['provider']['runner_os'], 'runner_arch': x['provider']['runner_arch'], 'beacon_round': x['beacon']['round'], 'beacon_randomness': x['beacon']['randomness'], 'derived_seed': x['derived_seed'], 'scientific_sha256': x['summary']['scientific_sha256'], 'advantage_pp': x['summary']['qew_advantage_percentage_points'], 'overall_pass': x['overall_pass']} for x in results]
    out = {
        'program': 'R144-S257A', 'study': 'BBQ-1 Public-Beacon Blind Quorum Rehearsal',
        'provider_count': len(results), 'providers': results, 'normalized_provider_results': normalized,
        'cross_provider_sha256': hashlib.sha256(cjson(normalized)).hexdigest(), 'checks': checks, 'overall_pass': all(checks.values()),
        'claim_ceiling': [
            'future public randomness removed post-freeze seed choice in this workflow',
            'same-party publicly seeded cross-provider replication supported',
            'unaffiliated evaluator-owned authority remains open',
            'underlying subject truth not established by witness',
            'full-collusion detection not supported',
            'unrestricted universal implementation superiority not coherent under comparator closure',
        ],
    }
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'provider_count': len(results), 'checks': checks, 'overall_pass': out['overall_pass'], 'cross_provider_sha256': out['cross_provider_sha256']}, indent=2, sort_keys=True))
    raise SystemExit(0 if out['overall_pass'] else 2)


if __name__ == '__main__': main()
