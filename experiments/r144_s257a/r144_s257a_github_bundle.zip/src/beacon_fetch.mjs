import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const fetchPolyfill = require('isomorphic-fetch');
const AbortControllerPolyfill = require('abort-controller');
const { defaultClient, fetchBeacon } = require('drand-client');

if (!globalThis.fetch) globalThis.fetch = fetchPolyfill;
if (!globalThis.AbortController) globalThis.AbortController = AbortControllerPolyfill;

const args = process.argv.slice(2);
const outIdx = args.indexOf('--out');
if (outIdx < 0 || !args[outIdx + 1]) throw new Error('missing --out');
const out = args[outIdx + 1];
const waitSeconds = Number(process.env.BEACON_WAIT_SECONDS || '35');
await new Promise(resolve => setTimeout(resolve, waitSeconds * 1000));
const client = defaultClient();
const beacon = await fetchBeacon(client);
const normalized = {
  source: 'League of Entropy drand default chain via verified drand-client 1.4.2',
  chain_hash: '8990e7a9aaed2ffed73dbd7092123d6f289930540d7651336225dc172e51b2ce',
  round: Number(beacon.round),
  randomness: String(beacon.randomness),
  signature: String(beacon.signature),
  previous_signature: beacon.previous_signature ? String(beacon.previous_signature) : null,
  cryptographically_verified_by_client: true,
  fetched_at_utc: new Date().toISOString(),
  github_sha: process.env.GITHUB_SHA || null,
  github_run_id: process.env.GITHUB_RUN_ID || null,
  github_run_attempt: process.env.GITHUB_RUN_ATTEMPT || null,
  wait_seconds_after_job_start: waitSeconds,
};
const canonical = JSON.stringify(normalized, Object.keys(normalized).sort()) + '\n';
normalized.beacon_record_sha256 = crypto.createHash('sha256').update(canonical).digest('hex');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify(normalized, null, 2) + '\n');
console.log(JSON.stringify({ round: normalized.round, randomness: normalized.randomness, beacon_record_sha256: normalized.beacon_record_sha256 }, null, 2));
