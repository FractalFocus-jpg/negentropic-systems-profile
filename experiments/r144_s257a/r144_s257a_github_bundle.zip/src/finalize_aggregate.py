#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path


def cjson(x): return (json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n').encode()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--providers', required=True)
    ap.add_argument('--selection', required=True)
    ap.add_argument('--quorum', required=True)
    ap.add_argument('--out', required=True)
    a=ap.parse_args()
    providers=json.loads(Path(a.providers).read_text())
    selection=json.loads(Path(a.selection).read_text())
    quorum=json.loads(Path(a.quorum).read_text())
    checks={
        'provider_aggregate_pass': bool(providers['overall_pass']),
        'selection_bias_study_pass': bool(selection['overall_pass']),
        'quorum_threshold_model_pass': bool(quorum['overall_pass']),
    }
    normalized={
        'provider_cross_sha256': providers['cross_provider_sha256'],
        'provider_scientific_sha256': sorted({p['summary']['scientific_sha256'] for p in providers['providers']}),
        'beacon_round': sorted({p['beacon']['round'] for p in providers['providers']}),
        'beacon_randomness': sorted({p['beacon']['randomness'] for p in providers['providers']}),
        'selection_null_public_bias_pp': selection['scenarios']['0.0']['PUBLIC_BEACON_ONE_SHOT']['bias_mean_pp'],
        'selection_null_best16_bias_pp': selection['scenarios']['0.0']['BEST_OF_16']['bias_mean_pp'],
        'selection_null_best32_bias_pp': selection['scenarios']['0.0']['BEST_OF_32']['bias_mean_pp'],
        'quorum_parameter_rows': quorum['parameter_rows'],
        'quorum_mismatch_count': len(quorum['mismatches']),
    }
    out={
        'program':'R144-S257A',
        'study':'BBQ-1 Public-Beacon Blind Quorum Rehearsal',
        'checks':checks,
        'overall_pass':all(checks.values()),
        'normalized':normalized,
        'scientific_sha256':hashlib.sha256(cjson(normalized)).hexdigest(),
        'terminal':'PUBLIC_BEACON_BLIND_REHEARSAL_PASS_UNAFFILIATED_AUTHORITY_OPEN',
        'claim_disposition':{
            'PUBLIC_BEACON_SEED_DISCRETION_RESISTANCE':'PASS',
            'MEASURABLE_SELECTION_BIAS_SUPPRESSION':'PASS',
            'SAME_PARTY_BEACON_SEEDED_CROSS_PROVIDER_REPLICATION':'PASS',
            'CONTRACT_RELATIVE_QUORUM_THRESHOLD_NECESSITY':'PASS',
            'UNAFFILIATED_EVALUATOR_OWNED_AUTHORITY':'OPEN',
            'UNDERLYING_SUBJECT_TRUTH':'NOT_ESTABLISHED_BY_WITNESS',
            'FULL_COLLUSION_DETECTION':'NOT_SUPPORTED',
            'UNRESTRICTED_UNIVERSAL_IMPLEMENTATION_SUPERIORITY':'NOT_COHERENT_UNDER_COMPARATOR_CLOSURE'
        }
    }
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True)+'\n')
    print(json.dumps(out, indent=2, sort_keys=True))
    raise SystemExit(0 if out['overall_pass'] else 2)

if __name__=='__main__': main()
