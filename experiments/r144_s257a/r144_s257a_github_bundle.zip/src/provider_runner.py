#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, platform, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPERIMENT = Path(os.environ.get('QEW_EXPERIMENT_PATH', ROOT / 'bbq1_experiment.py')).resolve()
VERIFIER = Path(os.environ.get('QEW_VERIFIER_PATH', ROOT / 'independent_verifier.py')).resolve()


def cjson(x):
    return (json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n').encode()


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def line_count(path: Path) -> int:
    if not path.exists():
        return 0
    with path.open('rb') as f:
        return sum(1 for _ in f)


def run(cmd, *, cwd=None, check=True):
    p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if check and p.returncode != 0:
        raise RuntimeError(f'command failed {p.returncode}: {cmd}\n{p.stdout}')
    return p


def main() -> int:
    out_root = Path(os.environ.get('QEW_OUTDIR', 'provider_output')).resolve()
    if out_root.exists(): shutil.rmtree(out_root)
    out_root.mkdir(parents=True)
    beacon_path = Path(os.environ.get('BEACON_PATH', 'BEACON.json')).resolve()
    beacon = json.loads(beacon_path.read_text())
    if not beacon.get('cryptographically_verified_by_client'):
        raise RuntimeError('beacon verification flag absent')
    seed_material = {
        'program': 'R144-S257A',
        'protocol': 'BBQ-1-PUBLIC-BEACON-v1',
        'chain_hash': beacon['chain_hash'],
        'round': beacon['round'],
        'randomness': beacon['randomness'],
        'github_sha': beacon.get('github_sha'),
    }
    seed_digest = hashlib.sha256(cjson(seed_material)).digest()
    seed = int.from_bytes(seed_digest[:8], 'big') & ((1 << 63) - 1)
    run_dir = out_root / 'run'; replay_dir = out_root / 'replay'
    run_dir.mkdir(); replay_dir.mkdir()

    cmd = [sys.executable, str(EXPERIMENT), '--outdir', str(run_dir), '--seed', str(seed), '--clean', '100', '--per-attack', '100']
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    partial = run_dir / 'CASE_RESULTS.partial.jsonl'
    deadline = time.time() + 240
    while time.time() < deadline and proc.poll() is None:
        if line_count(partial) >= 911:
            proc.kill(); break
        time.sleep(0.05)
    interrupted_rc = proc.wait(timeout=20)
    interrupted_lines = line_count(partial)
    if interrupted_lines < 911:
        tail = proc.stdout.read()[-4000:] if proc.stdout else ''
        raise RuntimeError(f'interruption threshold not reached: lines={interrupted_lines}, rc={interrupted_rc}\n{tail}')

    resume = run(cmd + ['--resume'])
    (out_root / 'RESUME_STDOUT.txt').write_text(resume.stdout, encoding='utf-8')
    verify_path = out_root / 'INDEPENDENT_VERIFIER.json'
    verifier = run([sys.executable, str(VERIFIER), '--result-dir', str(run_dir), '--out', str(verify_path)])
    (out_root / 'VERIFIER_STDOUT.txt').write_text(verifier.stdout, encoding='utf-8')

    replay = run([sys.executable, str(EXPERIMENT), '--outdir', str(replay_dir), '--seed', str(seed), '--clean', '100', '--per-attack', '100'])
    (out_root / 'REPLAY_STDOUT.txt').write_text(replay.stdout, encoding='utf-8')
    replay_verify_path = out_root / 'REPLAY_INDEPENDENT_VERIFIER.json'
    replay_verifier = run([sys.executable, str(VERIFIER), '--result-dir', str(replay_dir), '--out', str(replay_verify_path)])
    (out_root / 'REPLAY_VERIFIER_STDOUT.txt').write_text(replay_verifier.stdout, encoding='utf-8')

    summary = json.loads((run_dir / 'SUMMARY.json').read_text())
    replay_summary = json.loads((replay_dir / 'SUMMARY.json').read_text())
    verifier_obj = json.loads(verify_path.read_text())
    replay_verifier_obj = json.loads(replay_verify_path.read_text())
    result = {
        'program': 'R144-S257A',
        'study': 'BBQ-1 Public-Beacon Blind Quorum Rehearsal',
        'provider': {
            'platform': platform.platform(), 'python': sys.version,
            'runner_os': os.environ.get('RUNNER_OS', platform.system()),
            'runner_arch': os.environ.get('RUNNER_ARCH', platform.machine()),
            'github_run_id': os.environ.get('GITHUB_RUN_ID'),
            'github_run_attempt': os.environ.get('GITHUB_RUN_ATTEMPT'),
        },
        'beacon': beacon,
        'seed_material': seed_material,
        'derived_seed': seed,
        'derived_seed_sha256': hashlib.sha256(cjson(seed_material)).hexdigest(),
        'interruption': {'actual_process_kill': True, 'return_code': interrupted_rc, 'persisted_cases': interrupted_lines, 'threshold': 911},
        'summary': summary,
        'fresh_replay_scientific_sha256': replay_summary['scientific_sha256'],
        'fresh_replay_exact': summary['scientific_sha256'] == replay_summary['scientific_sha256'],
        'independent_verifier_pass': verifier_obj['pass'],
        'replay_independent_verifier_pass': replay_verifier_obj['pass'],
        'artifact_hashes': {
            'beacon': sha(beacon_path), 'run_summary': sha(run_dir / 'SUMMARY.json'),
            'run_receipt': sha(run_dir / 'RUN_RECEIPT.json'), 'run_cases': sha(run_dir / 'CASE_RESULTS.partial.jsonl'),
            'verifier': sha(verify_path), 'replay_summary': sha(replay_dir / 'SUMMARY.json'),
        },
    }
    result['overall_pass'] = bool(summary['overall_pass'] and summary.get('private_keys_deleted') and result['fresh_replay_exact'] and verifier_obj['pass'] and replay_verifier_obj['pass'])
    (out_root / 'PROVIDER_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'overall_pass': result['overall_pass'], 'runner_os': result['provider']['runner_os'], 'beacon_round': beacon['round'], 'derived_seed': seed, 'scientific_sha256': summary['scientific_sha256'], 'advantage_pp': summary['qew_advantage_percentage_points'], 'persisted_before_kill': interrupted_lines}, indent=2, sort_keys=True))
    return 0 if result['overall_pass'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
