#!/usr/bin/env python3
from __future__ import annotations
import argparse, itertools, json
from pathlib import Path

PROGRAM = "R144-S257A"
STUDY = "QT-1 Quorum Safety-Liveness Threshold Model"


def first_unsafe_pair(n: int, q: int, f: int):
    qs = list(itertools.combinations(range(n), q))
    sets = [set(x) for x in qs]
    for i, a in enumerate(sets):
        for b in sets[i+1:]:
            inter = a & b
            if len(inter) <= f:
                return {
                    "quorum_a": sorted(a),
                    "quorum_b": sorted(b),
                    "intersection": sorted(inter),
                    "faulty_cover": sorted(inter),
                }
    return None


def run(max_n: int):
    rows = []
    mismatches = []
    for n in range(1, max_n + 1):
        for f in range(0, n):
            for q in range(1, n + 1):
                witness = first_unsafe_pair(n, q, f)
                safety_enum = witness is None
                safety_formula = 2 * q > n + f
                liveness_enum = q <= n - f
                liveness_formula = q <= n - f
                row = {
                    "n": n, "f": f, "q": q,
                    "safety_enum": safety_enum,
                    "safety_formula": safety_formula,
                    "liveness_enum": liveness_enum,
                    "liveness_formula": liveness_formula,
                    "both": safety_enum and liveness_enum,
                }
                if witness is not None and len(rows) < 100000:
                    row["unsafe_counterexample"] = witness
                if safety_enum != safety_formula or liveness_enum != liveness_formula:
                    mismatches.append(row)
                rows.append(row)
    existence = []
    for n in range(1, max_n + 1):
        for f in range(0, n):
            possible = any(r["both"] for r in rows if r["n"] == n and r["f"] == f)
            formula = n > 3 * f
            admissible_q = [r["q"] for r in rows if r["n"] == n and r["f"] == f and r["both"]]
            existence.append({"n": n, "f": f, "possible": possible, "formula_n_gt_3f": formula, "admissible_q": admissible_q})
            if possible != formula:
                mismatches.append({"n": n, "f": f, "existence_possible": possible, "formula_n_gt_3f": formula})
    canonical = []
    for f in range(0, (max_n - 1)//3 + 1):
        n = 3*f + 1
        if n <= max_n:
            q = 2*f + 1
            row = next(r for r in rows if r["n"] == n and r["f"] == f and r["q"] == q)
            canonical.append({"n": n, "f": f, "q": q, "safety": row["safety_enum"], "liveness": row["liveness_enum"]})
    checks = {
        "all_safety_formula_matches": not any(r.get("safety_enum") != r.get("safety_formula") for r in rows),
        "all_liveness_formula_matches": not any(r.get("liveness_enum") != r.get("liveness_formula") for r in rows),
        "existence_iff_n_gt_3f": all(x["possible"] == x["formula_n_gt_3f"] for x in existence),
        "canonical_3f1_2f1_all_pass": all(x["safety"] and x["liveness"] for x in canonical),
        "zero_mismatches": len(mismatches) == 0,
    }
    return {
        "program": PROGRAM,
        "study": STUDY,
        "max_n": max_n,
        "parameter_rows": len(rows),
        "checks": checks,
        "overall_pass": all(checks.values()),
        "theorem": {
            "safety": "Two q-of-n certificates cannot conflict with at most f Byzantine signers iff 2q > n + f.",
            "liveness": "A quorum remains attainable after f unavailable or Byzantine nodes iff q <= n - f.",
            "joint_feasibility": "Safety and liveness are jointly attainable iff n > 3f; at n = 3f + 1, q = 2f + 1 is canonical.",
            "boundary": "These are contract-relative quorum conditions, not unrestricted implementation superiority or subject-matter truth validation.",
        },
        "canonical": canonical,
        "existence": existence,
        "mismatches": mismatches,
        "rows": rows,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--max-n", type=int, default=12)
    a = ap.parse_args()
    out = run(a.max_n)
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"parameter_rows": out["parameter_rows"], "checks": out["checks"], "overall_pass": out["overall_pass"], "canonical": out["canonical"]}, indent=2, sort_keys=True))
    raise SystemExit(0 if out["overall_pass"] else 2)


if __name__ == "__main__":
    main()
