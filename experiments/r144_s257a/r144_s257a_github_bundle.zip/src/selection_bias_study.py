#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, math, statistics
from pathlib import Path

PROGRAM = "R144-S257A"
STUDY = "SB-1 Seed-Discretion Selection-Bias Study"


def u01(tag: str) -> float:
    d = hashlib.sha256(tag.encode()).digest()
    x = int.from_bytes(d[:8], "big")
    return (x + 0.5) / 2**64


def normal(tag: str) -> float:
    u1 = max(u01(tag + ":u1"), 1e-15)
    u2 = u01(tag + ":u2")
    return math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)


def quantile(xs, q):
    ys = sorted(xs)
    if not ys:
        return None
    pos = (len(ys) - 1) * q
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    if lo == hi:
        return ys[lo]
    return ys[lo] * (hi - pos) + ys[hi] * (pos - lo)


def summarize(values, true_mean):
    return {
        "n": len(values),
        "mean_pp": statistics.fmean(values),
        "median_pp": statistics.median(values),
        "q05_pp": quantile(values, 0.05),
        "q95_pp": quantile(values, 0.95),
        "bias_mean_pp": statistics.fmean(values) - true_mean,
        "promotion_rate_ge_5pp": sum(v >= 5 for v in values) / len(values),
        "promotion_rate_ge_20pp": sum(v >= 20 for v in values) / len(values),
    }


def run(n_studies: int, sigma: float):
    scenarios = {}
    for true_mean in (-5.0, 0.0, 5.0):
        protocols = {
            "PUBLIC_BEACON_ONE_SHOT": [],
            "PRECOMMITTED_ONE_SHOT": [],
            "BEST_OF_4": [],
            "BEST_OF_8": [],
            "BEST_OF_16": [],
            "BEST_OF_32": [],
            "FIRST_NONNEGATIVE_OF_8_ELSE_LAST": [],
        }
        nonpublication = 0
        published_positive = []
        for study in range(n_studies):
            vals = [true_mean + sigma * normal(f"{PROGRAM}:{true_mean}:{study}:{i}") for i in range(32)]
            protocols["PUBLIC_BEACON_ONE_SHOT"].append(vals[0])
            protocols["PRECOMMITTED_ONE_SHOT"].append(vals[1])
            for k in (4, 8, 16, 32):
                protocols[f"BEST_OF_{k}"].append(max(vals[:k]))
            first = next((v for v in vals[:8] if v >= 0), vals[7])
            protocols["FIRST_NONNEGATIVE_OF_8_ELSE_LAST"].append(first)
            positives = [v for v in vals[:8] if v >= 0]
            if positives:
                published_positive.append(positives[0])
            else:
                nonpublication += 1
        summaries = {k: summarize(v, true_mean) for k, v in protocols.items()}
        summaries["PUBLISH_ONLY_IF_NONNEGATIVE_WITHIN_8"] = {
            **summarize(published_positive, true_mean),
            "nonpublication_rate": nonpublication / n_studies,
        }
        scenarios[str(true_mean)] = summaries
    null = scenarios["0.0"]
    checks = {
        "public_beacon_abs_bias_le_0_1pp": abs(null["PUBLIC_BEACON_ONE_SHOT"]["bias_mean_pp"]) <= 0.1,
        "precommit_abs_bias_le_0_1pp": abs(null["PRECOMMITTED_ONE_SHOT"]["bias_mean_pp"]) <= 0.1,
        "best_of_16_bias_ge_10pp": null["BEST_OF_16"]["bias_mean_pp"] >= 10.0,
        "best_of_32_bias_ge_15pp": null["BEST_OF_32"]["bias_mean_pp"] >= 15.0,
        "best_of_16_20pp_rate_ge_10x_one_shot": null["BEST_OF_16"]["promotion_rate_ge_20pp"] >= 10 * null["PUBLIC_BEACON_ONE_SHOT"]["promotion_rate_ge_20pp"],
    }
    out = {
        "program": PROGRAM,
        "study": STUDY,
        "n_studies_per_true_mean": n_studies,
        "sigma_pp": sigma,
        "scenarios": scenarios,
        "checks": checks,
        "overall_pass": all(checks.values()),
        "interpretation": "Future public randomness removes seed-choice discretion after protocol freeze, but does not by itself create unaffiliated evaluator authority or validate the subject claim.",
    }
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--n", type=int, default=100000)
    ap.add_argument("--sigma", type=float, default=10.0)
    a = ap.parse_args()
    out = run(a.n, a.sigma)
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"checks": out["checks"], "overall_pass": out["overall_pass"], "null": out["scenarios"]["0.0"]}, indent=2, sort_keys=True))
    raise SystemExit(0 if out["overall_pass"] else 2)


if __name__ == "__main__":
    main()
